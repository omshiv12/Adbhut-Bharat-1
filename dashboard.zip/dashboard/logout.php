<?php
session_start();
print_r($_SESSION);
session_unset();

print_r($_SESSION); 
?>
<script type="text/javascript">
	window.location.href="../index.html";
</script>